import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import ClientDashboard from './components/ClientDashboard';
import AdminDashboard from './components/AdminDashboard'; // Import AdminDashboard

function App() {
  return (
    <Routes>
      <Route path='/' element={<Login />} />
      <Route path='/register' element={<Register />} />
      <Route path='/client/*' element={<ClientDashboard />} />
      <Route path='/admin/*' element={<AdminDashboard />} />
    </Routes>
  );
}
export default App;
