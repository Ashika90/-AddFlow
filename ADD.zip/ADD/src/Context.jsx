import React, { createContext, useState } from 'react';

export const mycontext = createContext();

function Context({ children }) {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  
  return (
    <mycontext.Provider value={{ name, password, setName, setPassword }}>
      {children}
    </mycontext.Provider>
  );
}

export default Context;  