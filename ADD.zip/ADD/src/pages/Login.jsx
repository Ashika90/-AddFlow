import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { mycontext } from '../Context';
import axios from 'axios';
import '../style/Login.css';

function Login() {
    const { setName, setPassword } = useContext(mycontext);
    const [name, setLocalName] = useState('');
    const [password, setLocalPassword] = useState('');
    const navigate = useNavigate();
    // localStorage.setItem("username", name);
    async function handleData() {
        try {
            if (!name || !password) {
                alert("Enter username and password");
                return;
            }

            // Check for admin login
            if (name === "admin" && password === "admin@123") {
                localStorage.setItem("userRole", "admin");
                navigate('/admin');
                return;
            }

            // Fetch user data for normal users
            let response = await axios.get('http://localhost:3000/users');
            let users = response.data;

            let user = users.find((ele) => ele.password === password && ele.userName === name);

            if (user) {
                setName(name);
                setPassword(password);

                // Store user details in localStorage
                localStorage.setItem("userId", user.id);
                localStorage.setItem("userRole", "client");

                navigate('/client');
            } else {
                alert("Invalid username or password. Please try again.");
            }
        } catch (error) {
            alert("Error during login: " + error.message);
        }
    }

    return (
        <>
        <h1 className='welcome-title'>Welcome To AdFlow</h1>
         <div className="logindiv">
            <h2>Login User</h2>
            <input
                type="text"
                value={name}
                placeholder="Enter Username"
                onChange={(e) => setLocalName(e.target.value)}
                className="login-input"
            /><br />
            <input
                type="password"
                value={password}
                placeholder="Password"
                onChange={(e) => setLocalPassword(e.target.value)}
                className="login-input"
            /><br /><br />
            <button type="button" onClick={handleData} className="loginbtn">Login</button>
            <button onClick={() => navigate("/register")} className="signup-btn">Sign Up</button><br />
        </div>
        </>
    );
}

export default Login;
