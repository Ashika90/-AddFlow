import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/regi.css';

export default function Register() {
    const [data, setData] = useState({
        firstName: '',
        lastName: '',
        userName: '',
        password: '',
        client:[]
    });
    const [errorMessage, setMessage] = useState('');
    const navigate = useNavigate();

    function handleData(e) {
        setData({ ...data, [e.target.name]: e.target.value });
    }

    async function handleSubmit(e) {
        e.preventDefault();
        if (!data.firstName || !data.userName || !data.lastName || !data.password) {
            alert('All fields are required');
            return;
        }
        try {
            const response = await axios.get('http://localhost:3000/users');
            const existingUser = response.data.some(user => user.userName === data.userName);
            if (existingUser) {
                setMessage('This username already exists. Please pick another.');
            } else {
                setMessage('');
                const newUser = await axios.post('http://localhost:3000/users', data);

                // Store userId in localStorage
                localStorage.setItem("userId", newUser.data.id);

                navigate('/');
            }
        } catch (e) {
            console.error(e);
            setMessage('Something went wrong. Please try again.');
        }
    }

    function handleLogin() {
        navigate('/');
    }

    return (
        <div>
            <h1 className='titlewelcome-title'>Connect With AdFlow</h1>
        <div className="signdiv">
            <h3>Registration</h3>
            <form onSubmit={handleSubmit}>
                <label>First Name:</label>
                <input
                    type="text"
                    value={data.firstName}
                    name="firstName"
                    onChange={handleData}
                    className="input-field"
                /><br />
                <label>Last Name:</label>
                <input
                    type="text"
                    value={data.lastName}
                    name="lastName"
                    onChange={handleData}
                    className="input-field"
                /><br />
                <label>Username:</label>
                <input
                    type="text"
                    value={data.userName}
                    name="userName"
                    onChange={handleData}
                    className="input-field"
                /><br />
                <label>Password:</label>
                <input
                    type="password"
                    value={data.password}
                    name="password"
                    onChange={handleData}
                    className="input-field"
                /><br />
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                <button type="submit" className="submit-btn">Register</button>
            </form>
            <button onClick={handleLogin} className="login-btn-from-reg">Login</button>
        </div>
        </div>
    );
}
