import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminDashboardPage = () => {
  const [bankBalance, setBankBalance] = useState(0);
  const [totalCampaigns, setTotalCampaigns] = useState(0);
  const [approvedCampaigns, setApprovedCampaigns] = useState(0);
  const [pendingCampaigns, setPendingCampaigns] = useState(0);
  const [rejectedCampaigns, setRejectedCampaigns] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:3000/users"); // Fetch users
        const users = response.data;
        let total = 0;
        let approved = 0;
        let pending = 0;
        let rejected = 0;
        let balance = 0;

        users.forEach((user) => {
          if (user.client) {
            total += user.client.length;
            approved += user.client.filter((c) => c.status.toLowerCase() === "approved").length;
            pending += user.client.filter((c) => c.status.toLowerCase() === "pending").length;
            rejected += user.client.filter((c) => c.status.toLowerCase() === "rejected").length;
        
            balance += user.client
              .filter((c) => c.status.toLowerCase() !== "rejected")
              .reduce((sum, c) => sum + Number(c.budget || 0), 0);
          }
        });
        

        setTotalCampaigns(total);
        setApprovedCampaigns(approved);
        setPendingCampaigns(pending);
        setRejectedCampaigns(rejected);
        setBankBalance(balance);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Welcome to Admin Dashboard</h1>
      <div className="admin-stats">
        <div className="stat-card">
          <h2>💰 Bank Balance</h2>
          <p>${bankBalance.toLocaleString()}</p>
        </div>
        <div className="stat-card">
          <h2>📊 Total Campaigns</h2>
          <p>{totalCampaigns}</p>
        </div>
        <div className="stat-card">
          <h2>✅ Approved Campaigns</h2>
          <p>{approvedCampaigns}</p>
        </div>
        <div className="stat-card">
          <h2>⏳ Pending Campaigns</h2>
          <p>{pendingCampaigns}</p>
        </div>
        <div className="stat-card">
          <h2>❌ Rejected Campaigns</h2>
          <p>{rejectedCampaigns}</p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
