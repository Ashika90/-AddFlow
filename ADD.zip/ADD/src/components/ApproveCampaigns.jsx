import React from "react";
import axios from "axios";
import '../style/Approve.css'

const ApproveCampaigns = ({ users, setUsers }) => {
  const handleStatusChange = async (userId, campaignId, newStatus) => {
    const updatedUsers = users.map((user) => {
      if (user.id === userId) {
        return {
          ...user,
          client: user.client.map((campaign) =>
            campaign.id === campaignId ? { ...campaign, status: newStatus } : campaign
          ),
        };
      }
      return user;
    });

    setUsers(updatedUsers);

    try {
      await axios.put(`http://localhost:3000/users/${userId}`, {
        ...users.find((user) => user.id === userId),
        client: updatedUsers.find((user) => user.id === userId).client,
      });
    } catch (error) {
      console.error("Error updating campaign status:", error);
    }
  };

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Approve Campaigns</h1>
      {users.length === 0 ? (
        <p>No campaigns pending approval</p>
      ) : (
        <table className="dashboard-table">
          <thead>
            <tr>
              <th>User</th>
              <th>Campaign Title</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) =>
              user.client
                ?.filter((campaign) => campaign.status === "pending")
                .map((campaign) => (
                  <tr key={campaign.id}>
                    <td>{user.userName}</td>
                    <td>{campaign.title}</td>
                    <td className={`status ${campaign.status.toLowerCase()}`}>
                      {campaign.status}
                    </td>
                    <td>
                      <button onClick={() => handleStatusChange(user.id, campaign.id, "Approved")}>
                        Approve
                      </button>
                      <button onClick={() => handleStatusChange(user.id, campaign.id, "Rejected")}>
                        Reject
                      </button>
                    </td>
                  </tr>
                ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ApproveCampaigns;
