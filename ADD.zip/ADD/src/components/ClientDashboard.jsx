import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar";
import Dashboard from "../components/Dashboard";
import NewCampaign from "../components/NewCampaign";
import Profile from "../components/Profile";
import Transactions from "../components/Transactions";
import Support from "../components/Support";

const ClientDashboard = () => {
  const [campaigns, setCampaigns] = useState([]);
  const userId = localStorage.getItem("userId"); // Get logged-in user ID

  useEffect(() => {
    const fetchClientData = async () => {
      try {
        const response = await axios.get("http://localhost:3000/users");
        const users = response.data;

        // Find the logged-in user
        const loggedInUser = users.find(user => user.id === userId);

        if (loggedInUser) {
          setCampaigns(loggedInUser.client || []); // Set client's campaigns
        } else {
          console.error("User not found");
        }
      } catch (error) {
        console.error("Error fetching client data:", error);
      }
    };

    if (userId) {
      fetchClientData();
    }
  }, [userId]);

  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Dashboard campaigns={campaigns} />} />
        <Route path="new-campaign" element={<NewCampaign setCampaigns={setCampaigns} />} />
        <Route path="profile" element={<Profile />} />
        <Route path="transactions" element={<Transactions />} />
        <Route path="support" element={<Support />} />
      </Routes>
    </>
  );
};

export default ClientDashboard;
