
import '../style/AdminDash.css'
import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import axios from "axios";
import AdminNavbar from "../components/AdminNavbar";
import AdminDashboardPage from "../components/AdminDashboardPage";
import AllCampaigns from "../components/AllCampaigns";
import ApproveCampaigns from "../components/ApproveCampaigns";

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get("http://localhost:3000/users");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <>
      <AdminNavbar />
      <Routes>
        <Route path="/" element={<AdminDashboardPage />} />
        <Route path="all-campaigns" element={<AllCampaigns users={users} />} />
        <Route path="approve-campaigns" element={<ApproveCampaigns users={users} setUsers={setUsers} />} />
      </Routes>
    </>
  );
};

export default AdminDashboard;
