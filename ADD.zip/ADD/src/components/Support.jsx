import React from "react";
import "../style/Support.css";

const Support = () => {
  const supportData = [
    {
      id: 1,
      issue: "Payment not processed",
      status: "Resolved",
      date: "2025-03-20",
      response: "Your payment has been successfully processed now.",
    },
    {
      id: 2,
      issue: "Ad campaign approval delay",
      status: "Pending",
      date: "2025-03-22",
      response: "Your request is under review and will be approved soon.",
    },
    {
      id: 3,
      issue: "Login issues",
      status: "Resolved",
      date: "2025-03-18",
      response: "Your password was reset successfully. Try logging in again.",
    },
    {
      id: 4,
      issue: "Refund request for failed campaign",
      status: "In Progress",
      date: "2025-03-24",
      response: "Your refund is being processed and should be completed soon.",
    },
  ];

  const reviews = [
    {
      id: 1,
      user: "John Doe",
      rating: 5,
      comment: "Amazing platform! My campaigns were approved quickly.",
      date: "2025-03-22",
    },
    {
      id: 2,
      user: "Emily Smith",
      rating: 4,
      comment: "Good service, but the refund process took a bit longer.",
      date: "2025-03-21",
    },
    {
      id: 3,
      user: "Michael Johnson",
      rating: 3,
      comment: "Decent platform, but needs improvements in UI.",
      date: "2025-03-19",
    },
    {
      id: 4,
      user: "Sophia Williams",
      rating: 5,
      comment: "Great support team! They helped me with my campaign issues.",
      date: "2025-03-17",
    },
  ];

  return (
    <div className="support-container">
      <h2 className="support-title">Customer Support Tickets</h2>
      <table className="support-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Issue</th>
            <th>Status</th>
            <th>Date</th>
            <th>Response</th>
          </tr>
        </thead>
        <tbody>
          {supportData.map((ticket) => (
            <tr key={ticket.id}>
              <td>{ticket.id}</td>
              <td>{ticket.issue}</td>
              <td className={`status-${ticket.status.toLowerCase()}`}>
                {ticket.status}
              </td>
              <td>{ticket.date}</td>
              <td>{ticket.response}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 className="review-title">Customer Reviews</h2>
      <div className="review-container">
        {reviews.map((review) => (
          <div key={review.id} className="review-card">
            <h3 className="review-user">{review.user}</h3>
            <p className="review-rating">⭐ {review.rating}/5</p>
            <p className="review-comment">"{review.comment}"</p>
            <p className="review-date">{review.date}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Support;
