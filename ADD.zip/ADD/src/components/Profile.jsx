import React, { useEffect, useState } from "react";
import axios from "axios";
import "../style/Profile.css";

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [updatedProfile, setUpdatedProfile] = useState({
    firstName: "",
    lastName: "",
    userName: "",
  });

  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchProfile = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/users/${userId}`);
        setProfile(response.data);
        setUpdatedProfile({
          firstName: response.data.firstName,
          lastName: response.data.lastName,
          userName: response.data.userName,
        });
      } catch (error) {
        console.error("Error fetching profile:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleChange = (e) => {
    setUpdatedProfile({ ...updatedProfile, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) return;

    try {
      await axios.patch(`http://localhost:3000/users/${userId}`, updatedProfile);
      setProfile((prev) => ({ ...prev, ...updatedProfile })); // Update state without losing other fields
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };

  if (loading) return <div className="profile-container">Loading...</div>;
  if (!profile) return <div className="profile-container">User not found.</div>;

  return (
    <div className="profile-container">
      <h1 className="profile-title">Your Profile</h1>

      {isEditing ? (
        <>
          <input
            type="text"
            name="firstName"
            value={updatedProfile.firstName}
            onChange={handleChange}
            className="profile-input"
          />
          <input
            type="text"
            name="lastName"
            value={updatedProfile.lastName}
            onChange={handleChange}
            className="profile-input"
          />
          <input
            type="text"
            name="userName"
            value={updatedProfile.userName}
            onChange={handleChange}
            className="profile-input"
          />
          <button className="profile-button" onClick={handleSave}>
            Save Changes
          </button>
        </>
      ) : (
        <>
          <p className="profile-info"><strong>First Name:</strong> {profile.firstName}</p>
          <p className="profile-info"><strong>Last Name:</strong> {profile.lastName}</p>
          <p className="profile-info"><strong>Username:</strong> {profile.userName}</p>
          <button className="profile-button" onClick={handleEditClick}>
            Edit Profile
          </button>
        </>
      )}
    </div>
  );
};

export default Profile;
