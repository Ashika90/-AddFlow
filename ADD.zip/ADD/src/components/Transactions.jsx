import React, { useEffect, useState } from "react";
import axios from "axios";
import "../style/Transaction.css";

const Transaction = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchTransactions = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/users/${userId}`);

        if (response.data && response.data.client) {
          setTransactions(response.data.client);
        } else {
          setTransactions([]);
        }
      } catch (error) {
        console.error("Error fetching transactions:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  return (
    <div className="transaction-container">
      <h2 className="transaction-title">Your Transactions</h2>
      {loading ? (
        <p className="loading">Loading transactions...</p>
      ) : transactions.length === 0 ? (
        <p className="no-transaction">No transactions available</p>
      ) : (
        <table className="transaction-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Budget (USD)</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((campaign) => (
              <tr key={campaign.id}>
                <td>{campaign.id}</td>
                <td>{campaign.title}</td>
                <td>${campaign.budget.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Transaction;
