import React from "react";
import '../style/Allcampaign.css'
const AllCampaigns = ({ users }) => {
  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">All Campaigns</h1>
      {users.length === 0 ? (
        <p>No users found</p>
      ) : (
        users.map((user) => (
          <div key={user.id} className="user-campaigns">
            <h2 className="user-name">Client Name: {user.userName}</h2>
            {user.client && user.client.length > 0 ? (
              <table className="dashboard-table">
                <thead>
                  <tr>
                    <th>Campaign ID</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Countries</th>
                    <th>Devices</th>
                    <th>Duration</th>
                    <th>Budget</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {user.client.map((campaign) => (
                    <tr key={campaign.id}>
                      <td>{campaign.id}</td>
                      <td>{campaign.title}</td>
                      <td>
                        <img 
                          src={campaign.imageUrl} 
                          alt={campaign.title} 
                          style={{ width: "100px", height: "100px", objectFit: "cover", borderRadius: "8px" }} 
                        />
                      </td>
                      <td>{campaign.countries?.join(", ") || "N/A"}</td>
                      <td>{campaign.devices?.join(", ") || "N/A"}</td>
                      <td>{campaign.duration}</td>
                      <td>${campaign.budget}</td>
                      <td className={`status ${campaign.status?.toLowerCase()}`}>
                        {campaign.status}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="no-campaign">No campaigns available</p>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default AllCampaigns;
