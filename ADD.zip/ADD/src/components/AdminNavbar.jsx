import React from "react";
import { Link, useNavigate } from "react-router-dom";
const AdminNavbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("adminId"); 
    navigate("/"); 
  };

  return (
    <nav className="navbar">
      <h1>Admin Panel</h1>
      <div>
        <Link to="/admin">Dashboard</Link>
        <Link to="/admin/all-campaigns">All Campaigns</Link>
        <Link to="/admin/approve-campaigns">Approve Campaigns</Link>
        <button className="logout-btn" onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
};

export default AdminNavbar;
