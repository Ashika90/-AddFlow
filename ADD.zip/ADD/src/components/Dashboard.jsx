import React from "react";
import "../style/Dashbord.css"; 

const Dashboard = ({ campaigns = [] }) => {
  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Your Campaigns</h1>
      {campaigns.length === 0 ? (
        <p>No campaigns available</p>
      ) : (
        <table className="dashboard-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Countries</th>
              <th>Devices</th>
              <th>Duration</th>
              <th>Budget</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {campaigns.map((campaign) => (
              <tr key={campaign.id}>
                <td>{campaign.id}</td>
                <td>{campaign.title}</td>
                <td>{campaign.countries?.join(", ") || "N/A"}</td>
                <td>{campaign.devices?.join(", ") || "N/A"}</td>
                <td>{campaign.duration}</td>
                <td>${campaign.budget}</td>
                <td className={`status ${campaign.status?.toLowerCase()}`}>{campaign.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Dashboard;
