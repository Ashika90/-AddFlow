import React, { useState } from "react";
import axios from "axios";
import '../style/NewCampign.css'
import { useNavigate } from "react-router-dom";

const NewCampaign = ({ setCampaigns }) => {
  const navigate = useNavigate();
  const userId = localStorage.getItem("userId"); // Get logged-in user ID

  const [campaign, setCampaign] = useState({
    title: "",
    countries: [],
    devices: [],
    duration: "",
    budget: "",
    paymentMethod: "",
    imageUrl: "",
    status: "pending", // Default status
  });

  const countriesList = [
    "USA", "Canada", "UK", "India", "Australia", "Germany", "France", "Italy", "Spain", "Netherlands",
    "Brazil", "Mexico", "Argentina", "South Africa", "Japan", "South Korea", "China", "Russia", "UAE", "Saudi Arabia"
  ];
  
  const devicesList = [
    "Mobile", "Tablet", "Desktop", "Laptop", "Smart TV", "Wearable", "Gaming Console"
  ];
  

  const handleChange = (e) => {
    const { name, value, options } = e.target;
    if (name === "countries" || name === "devices") {
      setCampaign({
        ...campaign,
        [name]: Array.from(options).filter((o) => o.selected).map((o) => o.value),
      });
    } else {
      setCampaign({ ...campaign, [name]: value });
    }
  };

  const handleSubmit = async () => {
    if (!campaign.title || !campaign.budget || !campaign.duration || !campaign.imageUrl) {
      alert("Please fill in all required fields!");
      return;
    }

    try {
      // Fetch all users
      const { data: users } = await axios.get("http://localhost:3000/users");

      // Find the logged-in user dynamically
      const loggedInUser = users.find((user) => user.id === userId);

      if (!loggedInUser) {
        alert("User not found!");
        return;
      }

      // Generate a new campaign ID
      const newId = loggedInUser.client?.length
        ? (Math.max(...loggedInUser.client.map((c) => Number(c.id))) + 1).toString()
        : "1";

      // Create new campaign object
      const newCampaign = { ...campaign, id: newId };

      // Add new campaign to the logged-in user's "client" array
      const updatedClient = [...(loggedInUser.client || []), newCampaign];

      // Update the user data in the database
      await axios.patch(`http://localhost:3000/users/${loggedInUser.id}`, {
        client: updatedClient,
      });

      // Update state
      setCampaigns(updatedClient);

      alert("Campaign added successfully!");
      navigate("/client"); // Redirect to dashboard
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to add campaign!");
    }
  };

  return (
    <div className="campaign-container">
      <h1 className="campaign-title">Create New Campaign</h1>

      <div className="form-group">
        <label className="form-label">Title:</label>
        <input className="form-input" name="title" placeholder="Title" onChange={handleChange} />
      </div>

      <div className="form-group">
        <label className="form-label">Countries:</label>
        <select className="form-select" name="countries" multiple onChange={handleChange}>
          {countriesList.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label className="form-label">Devices:</label>
        <select className="form-select" name="devices" multiple onChange={handleChange}>
          {devicesList.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label className="form-label">Duration:</label>
        <input className="form-input" name="duration" placeholder="Duration (days)" onChange={handleChange} />
      </div>

      <div className="form-group">
        <label className="form-label">Budget:</label>
        <input className="form-input" name="budget" type="number" placeholder="Budget ($)" onChange={handleChange} />
      </div>

      <div className="form-group">
        <label className="form-label">Payment Method:</label>
        <select className="form-select" name="paymentMethod" onChange={handleChange}>
          <option value="">Select Payment</option>
          <option value="Credit Card">Credit Card</option>
          <option value="PayPal">PayPal</option>
          <option value="Bank Transfer">Bank Transfer</option>
        </select>
      </div>

      <div className="form-group">
        <label className="form-label">Advertisement Image URL:</label>
        <input className="form-input" name="imageUrl" placeholder="Enter Image URL" onChange={handleChange} />
      </div>

      <button className="form-button" onClick={handleSubmit}>
        Submit
      </button>
    </div>
  );
};

export default NewCampaign;
