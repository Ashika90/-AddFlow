import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "../style/Navbar.css"; 

const Navbar = () => {
  const navigate=useNavigate();
  function handle(){
    navigate('/')
  }
  return (
    <nav className="navbar">
      <h1>AdFlow</h1>
      <div>
        <Link to="/client">Dashboard</Link>
        <Link to="/client/new-campaign">New Campaign</Link>
        <Link to="/client/profile">Profile</Link>
        <Link to="/client/transactions">Transactions</Link>
        <Link to="/client/support">Support</Link>
        <button className="logout-btn" onClick={handle}>Logout</button>
      </div>
    </nav>
  );
};

export default Navbar;
